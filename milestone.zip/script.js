jQuery.noConflict();
(function( $ ) {
  $(function() {
    

    var state = localStorage.getItem('issueTacker');

    if(state != null){
    	    $('body').empty();
    		$('body').append(state);
    		$('.todoItem.done').find('input:checkbox').attr('checked', true);
    }




    $( "#datepicker" ).datepicker();


 
  	var formArray = [];

	bindDone();
	bindDelete()

  	$('#createIssue').on('submit', function(e){

  		var issue = '<tr class="todoItem"> <td><input type="checkbox" name="bla" /></td> <td>TITLE</td> <td>DATE</td> <td><img id="bin" class="delete" src="bin.png"></td> </tr>';

  		formArray = $(this).serializeArray();

  		date = String(formArray[0]['value']);
  		title = String(formArray[1]['value']);

  		issue = issue.replace('DATE', date);
  		issue = issue.replace('TITLE', title);

  		$('.tabelle tbody').prepend(issue);

  		$( ".todoItem input:checkbox" ).unbind();
  		$( ".todoItem .delete" ).unbind();

  		bindDone();
  		bindDelete()


  		$(this).trigger("reset");

  		localStorage.setItem('issueTacker', document.body.innerHTML);

  		e.preventDefault();

  	});

  	function bindDone(){
	  	$( ".todoItem input:checkbox" ).on('click', function(){
			$(this).parents('.todoItem').toggleClass('done');
			localStorage.setItem('issueTacker', document.body.innerHTML);
		});		
  	}


  	function bindDelete(){
		$( ".todoItem .delete" ).on('click', function(){
			$(this).parents('.todoItem').remove();
			localStorage.setItem('issueTacker', document.body.innerHTML);
		});  		
  	}

  });
})(jQuery);